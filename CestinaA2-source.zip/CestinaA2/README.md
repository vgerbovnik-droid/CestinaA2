# Čeština A2 (prototype v0.1)

Independent Android application, Russian/Czech interface, official NPI ČR online practice exam in an embedded WebView, official PDF opened externally, manual offline completion flags stored with SharedPreferences.

**Important:** The official exam is online; no test content is redistributed. This version does NOT implement native/offline question scoring, automatic synchronization of official exam results, or offline official test questions. Do not present manual completion flags as exam scores.

## Build
Open project in Android Studio (JDK 17), sync Gradle and Build > Build APK(s). Alternatively push the project to GitHub and run Actions > Build APK. Download the `CestinaA2-debug-apk` workflow artifact.

Official source: https://cestina-pro-cizince.cz/trvaly-pobyt/a2/priprava-na-zkousku/
