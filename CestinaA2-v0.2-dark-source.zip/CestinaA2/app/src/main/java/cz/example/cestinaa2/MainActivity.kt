package cz.example.cestinaa2

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.view.View
import android.widget.*
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest

class MainActivity : Activity() {
 private val source = "https://cestina-pro-cizince.cz/trvaly-pobyt/a2/cs/priprava-na-zkousku/"
 private val test = "https://cestina-pro-cizince.cz/trvaly-pobyt/a2/cs/priprava-na-zkousku/modelovy-test-novy-format/"
 private val pdf = "https://cestina-pro-cizince.cz/trvaly-pobyt/wp-content/uploads/2023/12/brozura_A2_2024-web.pdf"
 private lateinit var root: LinearLayout
 private var web: WebView? = null
 private val prefs by lazy { getSharedPreferences("progress", MODE_PRIVATE) }
 private var ru get() = prefs.getBoolean("ru", true)
  set(value) { prefs.edit().putBoolean("ru", value).apply() }
 private fun t(r: String, c: String) = if (ru) r else c
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); home() }
 private fun button(label: String, action: () -> Unit) { val b=Button(this); b.text=label; b.isAllCaps=false; root.addView(b); b.setOnClickListener { action() } }
 private fun title(s:String) { val v=TextView(this); v.text=s; v.textSize=23f; v.setTextColor(Color.WHITE); v.setPadding(0,18,0,20); root.addView(v) }
 private fun base() { web?.destroy(); web=null; root=LinearLayout(this); root.orientation=LinearLayout.VERTICAL; root.setPadding(24,25,24,18); root.setBackgroundColor(Color.rgb(22,25,34)); setContentView(root) }
 private fun visit(url:String) {
  base()
  button(t("← Назад","← Zpět")) { home() }
  val w=WebView(this)
  web=w
  root.addView(w,LinearLayout.LayoutParams(-1,0,1f))
  w.setBackgroundColor(Color.rgb(15,17,22))
  w.settings.javaScriptEnabled=true
  w.settings.domStorageEnabled=true
  w.webViewClient=object: WebViewClient() {
   override fun onPageFinished(view:WebView?, url:String?) {
    super.onPageFinished(view,url)
    if (url?.startsWith("https://cestina-pro-cizince.cz/")==true) view?.evaluateJavascript(DARK_JS,null)
   }
  }
  w.loadUrl(url)
 }
 private val DARK_JS = """(function(){
   if(document.getElementById('cestina-a2-dark-style')) return;
   var style=document.createElement('style');
   style.id='cestina-a2-dark-style';
   style.textContent=`
     html,body,main,article,section,header,footer,nav,
     .container,.content,.site-content,.entry-content,.elementor,
     .elementor-section,.elementor-container,.elementor-column,
     .elementor-widget-wrap,.elementor-widget-container {
       background-color:#15171e !important; color:#fff !important;
     }
     h1,h2,h3,h4,h5,h6,p,li,span,label,strong,small,
     blockquote,td,th,legend {color:#fff !important;}
     a {color:#78c7ff !important;}
     a:hover {color:#b4e2ff !important;}
     input,textarea,select,button,[role=button] {
       background-color:#292d38 !important; color:#fff !important;
       border-color:#6d7482 !important;
     }
     input::placeholder,textarea::placeholder {color:#c6c8d0 !important;}
     input[type=checkbox],input[type=radio] {accent-color:#78c7ff !important;}
     .alert,.warning,.notice,[class*=warning],[class*=alert] {
       background-color:#39202c !important; color:#fff !important;
     }
     img,video,canvas,svg,iframe {filter:none !important;}
   `;
   (document.head||document.documentElement).appendChild(style);
 })();"""
 private fun openExternal(url:String) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
 private fun mark(key:String) { prefs.edit().putBoolean(key,true).apply(); home() }
 private fun completed(key:String) = if(prefs.getBoolean(key,false)) " ✓" else ""
 private fun section(name:String,key:String) { base(); title(name); button(t("Открыть официальный тест","Otevřít oficiální test")) { visit(test) }; button(t("Отметить как выполнено","Označit jako dokončené")) { mark(key) }; button(t("← Главная","← Domů")) { home() } }
 private fun home() { base(); title("Čeština A2"); val subtitle=TextView(this); subtitle.text=t("Подготовка к экзамену • официальные материалы NPI ČR\nОтметки прогресса сохраняются на телефоне.","Příprava na zkoušku • oficiální materiály NPI ČR\nPostup se ukládá v telefonu."); subtitle.setTextColor(Color.LTGRAY); root.addView(subtitle)
 button(t("Язык: Русский / переключить","Jazyk: Čeština / přepnout")) { ru=!ru; home() }
 listOf(Triple("Čtení", "cteni", "Чтение"), Triple("Poslech", "poslech", "Аудирование"), Triple("Psaní", "psani", "Письмо"), Triple("Mluvení", "ml uveni".replace(" ",""), "Разговор")).forEach { (name,key,translation)-> button(name+" — "+(if(ru) translation else name)+completed(key)) { section(name,key) } }
 button(t("Полный официальный тест","Celý oficiální test")) { visit(test) }
 button(t("Брошюра A2 2024 (PDF)","Brožura A2 2024 (PDF)")) { openExternal(pdf) }
 button(t("Все официальные материалы","Všechny oficiální materiály")) { visit(source) }
 val info=TextView(this); info.text=t("Тест требует интернет. Прогресс офлайн — это ручные отметки, а не автоматически полученные баллы. Независимое приложение, не продукт NPI ČR.","Test vyžaduje internet. Offline postup tvoří ruční označení, nikoli automaticky získané body. Nezávislá aplikace, nejde o produkt NPI ČR."); info.setTextColor(Color.LTGRAY); info.setPadding(0,16,0,0); root.addView(info)
 }
 @Deprecated("Deprecated in Java") override fun onBackPressed() { if(web?.canGoBack()==true) web?.goBack() else home() }
}
