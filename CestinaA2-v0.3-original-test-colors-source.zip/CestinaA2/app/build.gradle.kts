plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "cz.example.cestinaa2"; compileSdk = 35
 defaultConfig { applicationId = "cz.example.cestinaa2"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "0.1" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
}
