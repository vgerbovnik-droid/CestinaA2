# Čeština A2 (prototype v0.1)

Independent Android application, Russian/Czech interface, official NPI ČR online practice exam in an embedded WebView, official PDF opened externally, manual offline completion flags stored with SharedPreferences.

**Important:** The official exam is online; no test content is redistributed. This version does NOT implement native/offline question scoring, automatic synchronization of official exam results, or offline official test questions. Do not present manual completion flags as exam scores.

## Build
Open project in Android Studio (JDK 17), sync Gradle and Build > Build APK(s). Alternatively push the project to GitHub and run Actions > Build APK. Download the `CestinaA2-debug-apk` workflow artifact.

Official source: https://cestina-pro-cizince.cz/trvaly-pobyt/a2/priprava-na-zkousku/

## v0.2 — dark WebView
The NPI website opened inside the app now receives an optional dark CSS overlay after each page load. Text is white and controls are dark. The overlay does not alter the official website or its grading logic. Since the website is third-party, some dynamically rendered widgets may retain their original appearance. Internet access is still required.

## v0.3
Restored original website styling in WebView to avoid unreadable official exam questions. App navigation remains dark.
